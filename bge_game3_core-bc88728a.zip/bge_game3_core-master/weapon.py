####
# bge_game3_core: Full python game structure for the Blender Game Engine
# Copyright (C) 2019  DaedalusMDW @github.com (Daedalus_MDW @blenderartists.org)
# https://github.com/DaedalusMDW/bge_game3_core
#
# This file is part of bge_game3_core.
#
#    bge_game3_core is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    bge_game3_core is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with bge_game3_core.  If not, see <http://www.gnu.org/licenses/>.
#
####

## WEAPON CORE ##


from bge import logic

from . import attachment, keymap


class CoreWeapon(attachment.CoreAttachment):

	NAME = "Weapon"
	ENABLE = False
	SLOTS = []
	COLOR = (0,1,0,1)
	TYPE = "RANGED"

	def assignToPlayer(self):
		super().assignToPlayer()

		slot = self.owning_slot
		cls = self.owning_player

		if self.TYPE not in cls.data["WPDATA"]["WHEEL"]:
			cls.data["WPDATA"]["WHEEL"][self.TYPE] = {"ID":-1, "LIST":[]}

		if slot not in cls.data["WPDATA"]["WHEEL"][self.TYPE]["LIST"]:
			cls.data["WPDATA"]["WHEEL"][self.TYPE]["LIST"].append(slot)

	def removeFromPlayer(self):
		super().removeFromPlayer()

		slot = self.owning_slot
		cls = self.owning_player

		if cls == None:
			return

		weap = cls.data["WPDATA"]["WHEEL"][self.TYPE]

		if slot in weap["LIST"]:
			weap["LIST"].remove(slot)

		if weap["ID"] >= len(weap["LIST"]):
			weap["ID"] = len(weap["LIST"])-1


class CorePlayerWeapon(CoreWeapon):

	HAND = "AUTO"
	WAIT = 40
	ANIMSTANCE = ""

	def defaultStates(self):
		super().defaultStates()
		self.active_post.append(self.PS_HandSocket)

	def defaultData(self):
		self.handobj = None
		return {"HAND":None}

	def assignToPlayer(self):
		super().assignToPlayer()

		try:
			hand = self.data["HAND"]
			if self.data["ENABLE"] == True and hand != None:
				self.handobj = self.owning_player.objects["SKT"][hand]
		except:
			self.handobj = None
			self.data["HAND"] = None

	def removeFromPlayer(self):
		super().removeFromPlayer()

		self.handobj = None
		self.data["HAND"] = None

	def attachToSocket(self, obj=None, socket=None):
		if socket == None:
			return
		if obj == None:
			obj = self.objects["Root"]

		obj.setParent(socket)
		obj.localOrientation = self.createMatrix()

		if socket == self.box:
			obj.localPosition = self.getSocketPos()
			obj.localScale = self.getSocketScale()
		else:
			obj.localPosition = (0,0,0)
			obj.worldScale = (1,1,1)

	def checkHand(self):
		plr = self.owning_player
		if plr == None:
			return None

		l = [self.HAND]
		if self.HAND == "AUTO":
			l = ["MAIN", "OFF"]

		hand = None
		for h in l:
			if hand == None:
				try:
					if len(plr.objects["SKT"][plr.HAND[h]].children) == 0:
						hand = plr.HAND[h]
				except:
					hand = None

		return hand

	def doPlayerAnim(self, frame=0):
		plr = self.owning_player
		hand = self.data["HAND"]
		if hand == None or plr == None:
			return

		anim = self.TYPE+hand+self.owning_slot
		start = 0
		end = 40
		lyr = 1+(self.HAND=="OFF")

		if frame == "LOOP":
			plr.doAnim(NAME=plr.ANIMSET+anim, FRAME=(end,end), LAYER=lyr, PRIORITY=2, MODE="LOOP")
		elif frame == "STOP":
			plr.doAnim(LAYER=lyr, STOP=True)
		elif type(frame) is int:
			plr.doAnim(NAME=plr.ANIMSET+anim, FRAME=(start,end), LAYER=lyr)
			fac = (frame/self.WAIT)
			if frame < 0:
				fac = 1+fac
			plr.doAnim(LAYER=lyr, SET=fac*end)

	def PS_HandSocket(self):
		mesh = self.objects["Mesh"]
		sock = self.objects["Socket"]

		if self.handobj != None:
			sock = self.handobj

		if mesh.parent != sock:
			self.attachToSocket(mesh, sock)

	## STATE TRANSITION ##
	def ST_Enable(self):
		if self.data["HAND"] == None:
			hand = self.checkHand()
			if hand == None:
				self.doPlayerAnim("STOP")
				self.data["ENABLE"] = False
				self.data["COOLDOWN"] = 0
				self.data["HAND"] = None
				self.active_state = self.ST_Idle
				return
			else:
				self.data["HAND"] = hand

		if self.data["COOLDOWN"] >= self.WAIT*0.5:
			try:
				self.handobj = self.owning_player.objects["SKT"][self.data["HAND"]]
			except:
				self.handobj = None

		self.data["COOLDOWN"] += 1
		self.doPlayerAnim(self.data["COOLDOWN"])

		if self.data["COOLDOWN"] >= self.WAIT:
			self.data["COOLDOWN"] = 0
			self.active_state = self.ST_Active

	def ST_Stop(self):
		self.data["COOLDOWN"] += 1
		if self.dict["Equiped"] == "DROP":
			self.data["COOLDOWN"] = self.WAIT
		else:
			self.doPlayerAnim(self.WAIT-self.data["COOLDOWN"])

		if self.data["COOLDOWN"] >= self.WAIT*0.5:
			self.handobj = None

		if self.data["COOLDOWN"] >= self.WAIT:
			self.doPlayerAnim("STOP")
			self.data["COOLDOWN"] = 0
			self.data["HAND"] = None
			self.active_state = self.ST_Idle



